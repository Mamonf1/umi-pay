package Com.umni.pay

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
